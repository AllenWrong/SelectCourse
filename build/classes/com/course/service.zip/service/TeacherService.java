package com.course.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.course.bean.AskCourse;
import com.course.bean.OrderCourseInfo;
import com.course.bean.StuGrade;
import com.course.bean.TeacherInfor;
import com.course.dao.AskCourseDao;
import com.course.dao.OrderCourseInfoDao;
import com.course.dao.StuGradeDao;
import com.course.dao.TeaCouInfoDao;
import com.course.dao.TeacherInfoDao;
import com.course.jdbc.DatabaseConnection;

public class TeacherService {
	/** ��̬����*/
	private final String dbname="course_manager";
	/** ��ʦ�������ݿ���û���*/
	private String username;
	/** ��ʦ�������ݿ������*/
	private String password;
	
	public TeacherService(String username,String passwd) {
		this.username = username;
		this.password = passwd;
	}
	
	/** 
	 * �鿴��ʦ�Ļ�����Ϣ
	 * @param teaNum ��ʦ�Ĺ���
	 * @return
	 */
	public Object viewBasicInfo(String teaNum) {
		Connection connection = DatabaseConnection.getConnection(username,password, dbname);
		TeacherInfoDao teacherInfoDao = new TeacherInfoDao(connection);
		TeacherInfor teacherInfor = new TeacherInfor();
		try {
			teacherInfor = (TeacherInfor)teacherInfoDao.findByMainKey(teaNum);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DatabaseConnection.release(connection);
		}
		return teacherInfor;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<AskCourse> viewAskCourNoProcess(String teaNum) {
		Connection connection = DatabaseConnection.getConnection(username,password, dbname);
		AskCourseDao askCourseDao = new AskCourseDao(connection);
		ArrayList<AskCourse> list = new ArrayList<>();
		try {
			list = (ArrayList<AskCourse>) askCourseDao.findByMainKey(teaNum);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DatabaseConnection.release(connection);
		}
		return list;
	}
	
	/** �޸Ľ�ʦ�Ļ�����Ϣ��ui�ϲ�û���ṩ������Ϣ���޸ģ�������ﲻʵ�ָ÷���*/
	public Object updateBasicInfo() {
		return null;
	}
	
	/**
	 * ��ʦ���뿪�ι���
	 * @param object �������뿪����Ϣ�Ķ���
	 * @return
	 */
	public boolean askOpenCourse(Object object) {
		Connection connection = DatabaseConnection.getConnection(username,password, dbname);
		AskCourseDao askCourseDao = new AskCourseDao(connection);
		boolean flag = false;
		try {
			flag = askCourseDao.doCreate(object);
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}finally {
			DatabaseConnection.release(connection);
		}
		return flag;
	}
	
	/**
	 * �������뿪��
	 * @param object ����������Ϣ�Ķ���
	 * @return
	 */
	public boolean deleteAskOpenCourse(Object object) {
		Connection connection = DatabaseConnection.getConnection(username,password, dbname);
		AskCourseDao askCourseDao = new AskCourseDao(connection);
		boolean flag = false;
		try {
			flag = askCourseDao.doDelete(object);
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}finally {
			DatabaseConnection.release(connection);
		}
		return flag;
	}
	/**
	 * �鿴��ʦ�ĵ���
	 * @param object ����ѯ�Ľ�ʦ����
	 * @return
	 */
	public Object viewAchives(Object object) {
		return null;
	}
	
	/**
	 * �鿴��ʦ�Ŀγ̱�
	 * @param object ��ѯ�Ľ�ʦ����
	 * @return   orderCourseInfoDao����
	 */
	public ArrayList<OrderCourseInfo> viewCourseTable(String teaNum) {
		Connection conn = DatabaseConnection.getConnection(username, password, "course_manager");
		ArrayList<OrderCourseInfo> list = new ArrayList<>();
		OrderCourseInfoDao ordDao = new OrderCourseInfoDao(conn);
		try {
			list = ordDao.findByTeacher(teaNum);
		} catch (Exception e) {
			System.out.println("ҵ�񣺲�ѯ��ʦ�γ̱��쳣");
			e.printStackTrace();
		}finally {
			DatabaseConnection.release(conn);
		}
		return list;
	}
	
	/**
	 * ¼��ɼ�
	 * @param object ��¼��ĳɼ�����
	 * @return
	 */
	public boolean insertGrade(Object object) {
		Connection connection = DatabaseConnection.getConnection(username,password, dbname);
		StuGradeDao stuGradeDao = new StuGradeDao(connection);
		boolean flag = false;
		try {
			flag = stuGradeDao.doCreate(object);
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}finally {
			DatabaseConnection.release(connection);
		}
		return flag;
	}
	
	/**
	 * �鿴ָ���Ĵ�¼��ɼ��Ŀγ�
	 * @return
	 */
	public ArrayList<StuGrade> viewCourseByTeaCTY(String teaNum,String couNum,String term,String year) {
		Connection connection = DatabaseConnection.getConnection(username,password, dbname);
		StuGradeDao stuGradeDao = new StuGradeDao(connection);
		ArrayList<StuGrade> list = new ArrayList<>();
		try {
			list = stuGradeDao.findByTeaCTY(teaNum, couNum, term, year);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DatabaseConnection.release(connection);
		}
		return list;
	}
	
	/**
	 * �鿴�γ̳ɼ�
	 * @return
	 */
	public ArrayList<StuGrade> viewTeaCourseGrade(String teaNum,String couNum,String term,String year) {
		Connection connection = DatabaseConnection.getConnection(username,password, dbname);
		StuGradeDao stuGradeDao = new StuGradeDao(connection);
		ArrayList<StuGrade> list = new ArrayList<>();
		try {
			list = stuGradeDao.findGradeByTea(teaNum, couNum, term, year);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DatabaseConnection.release(connection);
		}
		return list;
	}
	
	/**
	 * ��ʦ�ڿ���Ϣ��ѯ
	 * @param teaNum ��ʦ��
	 * @return
	 */
	public ArrayList<OrderCourseInfo> viewTeaCouInfo(String teaNum){
		Connection connection = DatabaseConnection.getConnection(username, password, dbname);
		TeaCouInfoDao teaCouInfoDao = new TeaCouInfoDao(connection);
		ArrayList<OrderCourseInfo> list = new ArrayList<>();
		try {
			list = teaCouInfoDao.teaFindTeaCou(teaNum);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DatabaseConnection.release(connection);
		}
		return list;
	}
	
	
	/**
	 * �鿴��ʦ�е��Ŀ�����Ŀ
	 * @param object ����ѯ�Ľ�ʦ
	 * @return
	 */
	public Object viewReaserch(Object object) {
		return null;
	}
	
	/**
	 * �鿴��ʦ������ר��������
	 * @param object ����ѯ�Ľ�ʦ
	 * @return
	 */
	public Object viewProp(Object object) {
		return null;
	}
}